<?php
	require "db_connect.php";
	session_start();
	
	if(empty($_SESSION['type']));
	else if(strcmp($_SESSION['type'], "librarian") == 0)
		header("Location: librarian/home.php");
	else if(strcmp($_SESSION['type'], "member") == 0)
		header("Location: member/home.php");
?>

<html>
	<head>


		<title>Library</title>
		<link rel="stylesheet" type="text/css" href="css/index_style.css" />
		<!--=google fonts=====--->
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400&display=swap" rel="stylesheet">
	</head>
	<body>
		<div class="navbar">

			<ul class="nav_list">
				<li class="nav_item item">
					<a href="member">Login as Student</a>
				</li>
				<li class="nav_item item">
					<a href="librarian">Login as Librarian</a>
				</li>
			</ul>
		</div>
		<div class="hero" style="background: url(img/banner.jpeg);">
			
		</div>
		<div class="info">
			<h2 class="htext">
				Hola! Welcome to <span>Library</span>.
				<hr>
			</h2>
		</div>
		
	</body>
</html>