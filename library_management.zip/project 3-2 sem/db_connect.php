<?php
	$con = mysqli_connect('localhost', 'root', '', 'library');
	if(!$con)
		die("ERROR: Couldn't connect to database");
?>